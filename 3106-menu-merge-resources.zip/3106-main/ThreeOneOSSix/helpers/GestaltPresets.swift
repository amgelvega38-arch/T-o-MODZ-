import Foundation

/// MobileGestalt capability presets (GestaltX parity). Every key below is a
/// real CacheExtra key cross-checked against GestaltX (GPL-3.0), MGKeys,
/// Nugget and mond — never invent a key: on iOS 27, adding a key that did
/// not exist in the original cache can trip the boot-time cache validation
/// and force a full rebuild (restart bounce, Erosion's core lesson).
///
/// Risk profiles are structured (what happens / worst case / recovery) and
/// resolved through localization keys at render time. Category-level notes
/// are shared; identity-level presets add their own overrides.
enum GestaltPresetCategory: String, CaseIterable, Identifiable {
    case display
    /// Camera / audio / health capability bits. These live in `CacheData`
    /// slots, not CacheExtra — the reason they are read through
    /// GestaltCacheDataBridge.
    case media
    case device
    case ipad
    case intelligence
    case advanced

    var id: String { rawValue }

    var titleKey: String { "gestalt.category.\(rawValue)" }
    var icon: String {
        switch self {
        case .display: return "display"
        case .media: return "camera"
        case .device: return "iphone"
        case .ipad: return "ipad.landscape"
        case .intelligence: return "sparkles"
        case .advanced: return "wrench.and.screwdriver"
        }
    }
}

enum GestaltRiskLevel: String, Comparable {
    case low
    case medium
    case high

    static func < (lhs: GestaltRiskLevel, rhs: GestaltRiskLevel) -> Bool {
        let order: [GestaltRiskLevel] = [.low, .medium, .high]
        return order.firstIndex(of: lhs)! < order.firstIndex(of: rhs)!
    }
}

struct GestaltPreset: Identifiable {
    let id: String
    let category: GestaltPresetCategory
    let titleKey: String
    let detailKey: String
    /// CacheExtra keys toggled by this preset.
    let keys: [String]
    /// Custom per-key values for presets that are not a plain Boolean 1.
    var values: [String: Any]? = nil
    var riskLevel: GestaltRiskLevel = .medium
    /// Identity presets (device/region spoofing) need the full-screen risk
    /// confirmation before any write.
    var requiresRiskConfirmation: Bool = false
    /// Erosion-CN v0.8.5 baseline rule: some slots ship FALSE at the factory
    /// and enabling them breaks other system pipelines (Audio Intelligence
    /// → photos high-quality Clean Up). These presets are OFF by default and
    /// the engine refuses to enable them unless the value already exists.
    var factoryBaselineProtected: Bool = false
    /// GestaltX #102/#98 rule (siriOnDevice): the factory value is a
    /// device-specific enum (0-4 per machine); writing ANY generic value
    /// (true/1/false/0) can revert the AI Siri interface. Such presets
    /// expose only keep / restore-original / remove-key — no generic write.
    var preserveOnly: Bool = false

    var riskKey: String {
        // Per-preset overrides live at "risk.gestalt.<id>.*"; category-level
        // defaults at "risk.gestalt.category.<category>.*".
        "risk.gestalt.\(id)"
    }

    /// Resolve the risk note keys: prefer per-preset copy, fall back to the
    /// category defaults. The view checks existence via the localized bundle.
    var consequenceKey: String { "\(riskKey).consequence" }
    var worstCaseKey: String { "\(riskKey).worst_case" }
    var recoveryKey: String { "\(riskKey).recovery" }

    var categoryConsequenceKey: String { "risk.gestalt.category.\(category.rawValue).consequence" }
    var categoryWorstCaseKey: String { "risk.gestalt.category.\(category.rawValue).worst_case" }
    var categoryRecoveryKey: String { "risk.gestalt.category.\(category.rawValue).recovery" }
}

enum GestaltPresets {
    // MARK: - Preset table

    static let all: [GestaltPreset] = [
        // Display
        .init(id: "dynamicIsland", category: .display, titleKey: "gestalt.preset.dynamicIsland.title", detailKey: "gestalt.preset.dynamicIsland.detail", keys: ["YlEtTtHlNesRBMal1CqRaA"], riskLevel: .low),
        .init(id: "aod", category: .display, titleKey: "gestalt.preset.aod.title", detailKey: "gestalt.preset.aod.detail", keys: ["2OOJf1VhaM7NxfRok3HbWQ", "j8/Omm6s1lsmTDFsXjsBfA"], riskLevel: .medium),
        .init(id: "aodVibrancy", category: .display, titleKey: "gestalt.preset.aodVibrancy.title", detailKey: "gestalt.preset.aodVibrancy.detail", keys: ["ykpu7qyhqFweVMKtxNylWA"], riskLevel: .low),
        .init(id: "aodHighLuminance", category: .display, titleKey: "gestalt.preset.aodHighLuminance.title", detailKey: "gestalt.preset.aodHighLuminance.detail", keys: ["7brdL5xrEUWnlF9C0kdg5A"], riskLevel: .medium),
        .init(id: "aodFlipbook", category: .display, titleKey: "gestalt.preset.aodFlipbook.title", detailKey: "gestalt.preset.aodFlipbook.detail", keys: ["aoJSd/MXk7M40NgXTM6x+g"], riskLevel: .low),
        .init(id: "aodFlipbookCount", category: .display, titleKey: "gestalt.preset.aodFlipbookCount.title", detailKey: "gestalt.preset.aodFlipbookCount.detail", keys: ["qqrspu7CpuPdZwSDxNY+Fg"], values: ["qqrspu7CpuPdZwSDxNY+Fg": NSNumber(value: 3)], riskLevel: .medium),
        .init(id: "hdrPhotoDisplay", category: .display, titleKey: "gestalt.preset.hdrPhotoDisplay.title", detailKey: "gestalt.preset.hdrPhotoDisplay.detail", keys: ["a1r7npIrhXsZ7SmKRKC1eA"], riskLevel: .low),
        .init(id: "parallax", category: .display, titleKey: "gestalt.preset.parallax.title", detailKey: "gestalt.preset.parallax.detail", keys: ["UIParallaxCapability"], values: ["UIParallaxCapability": NSNumber(value: 0)], riskLevel: .low),
        .init(id: "pwm", category: .display, titleKey: "gestalt.preset.pwm.title", detailKey: "gestalt.preset.pwm.detail", keys: ["6IejgN+1Fmu5/QrZFOIeNw"], riskLevel: .medium),
        .init(id: "displayPort", category: .display, titleKey: "gestalt.preset.displayPort.title", detailKey: "gestalt.preset.displayPort.detail", keys: ["CoWnN4xo783YGn4wLrUatA"], riskLevel: .medium),
        .init(id: "liquidGlass", category: .display, titleKey: "gestalt.preset.liquidGlass.title", detailKey: "gestalt.preset.liquidGlass.detail", keys: ["SAGvsp6O6kAQ4fEfDJpC4Q"], riskLevel: .low),

        // Device
        .init(id: "bootChime", category: .device, titleKey: "gestalt.preset.bootChime.title", detailKey: "gestalt.preset.bootChime.detail", keys: ["QHxt+hGLaBPbQJbXiUJX3w"], riskLevel: .low),
        .init(id: "chargeLimit", category: .device, titleKey: "gestalt.preset.chargeLimit.title", detailKey: "gestalt.preset.chargeLimit.detail", keys: ["37NVydb//GP/GrhuTN+exg"], riskLevel: .low),
        .init(id: "tapToWake", category: .device, titleKey: "gestalt.preset.tapToWake.title", detailKey: "gestalt.preset.tapToWake.detail", keys: ["yZf3GTRMGTuwSV/lD7Cagw"], riskLevel: .low),
        .init(id: "cameraControl", category: .device, titleKey: "gestalt.preset.cameraControl.title", detailKey: "gestalt.preset.cameraControl.detail", keys: ["CwvKxM2cEogD3p+HYgaW0Q", "oOV1jhJbdV3AddkcCg0AEA"], riskLevel: .low),
        .init(id: "actionButton", category: .device, titleKey: "gestalt.preset.actionButton.title", detailKey: "gestalt.preset.actionButton.detail", keys: ["cT44WE1EohiwRzhsZ8xEsw"], riskLevel: .low),
        .init(id: "collisionSOS", category: .device, titleKey: "gestalt.preset.collisionSOS.title", detailKey: "gestalt.preset.collisionSOS.detail", keys: ["HCzWusHQwZDea6nNhaKndw"], riskLevel: .low),
        // Media / camera / health — CacheData boolean slots
        .init(id: "audioMix", category: .media, titleKey: "gestalt.preset.audioMix.title", detailKey: "gestalt.preset.audioMix.detail", keys: [MGCacheDataLayout.audioMixKey], riskLevel: .low),
        .init(id: "spatialFaceTimeAudio", category: .media, titleKey: "gestalt.preset.spatialFaceTimeAudio.title", detailKey: "gestalt.preset.spatialFaceTimeAudio.detail", keys: [MGCacheDataLayout.spatialFaceTimeAudioKey], riskLevel: .low),
        .init(id: "spatialAudioRec", category: .media, titleKey: "gestalt.preset.spatialAudioRec.title", detailKey: "gestalt.preset.spatialAudioRec.detail", keys: [MGCacheDataLayout.spatialAudioRecKey], riskLevel: .low),
        .init(id: "responsiveShutter", category: .media, titleKey: "gestalt.preset.responsiveShutter.title", detailKey: "gestalt.preset.responsiveShutter.detail", keys: [MGCacheDataLayout.responsiveShutterKey], riskLevel: .low),
        .init(id: "hypertensionNotif", category: .media, titleKey: "gestalt.preset.hypertensionNotif.title", detailKey: "gestalt.preset.hypertensionNotif.detail", keys: [MGCacheDataLayout.hypertensionNotifKey], riskLevel: .medium),
        .init(id: "shutterMute", category: .media, titleKey: "gestalt.preset.shutterMute.title", detailKey: "gestalt.preset.shutterMute.detail", keys: [MGCacheDataLayout.shutterRelaxationKey, MGCacheDataLayout.shutterKeyboardMutePreserveKey, MGCacheDataLayout.shutterLegacyMutePreserveKey], riskLevel: .medium),
        .init(id: "concurrentMics", category: .media, titleKey: "gestalt.preset.concurrentMics.title", detailKey: "gestalt.preset.concurrentMics.detail", keys: [MGCacheDataLayout.concurrentHPLPMicsKey], riskLevel: .low),
        .init(id: "photoRelight", category: .media, titleKey: "gestalt.preset.photoRelight.title", detailKey: "gestalt.preset.photoRelight.detail", keys: [MGCacheDataLayout.photosLocalLightKey, MGCacheDataLayout.toneMappingKey, MGCacheDataLayout.hdrDeferredProcessingKey], riskLevel: .medium),
        .init(id: "videoOverCapture", category: .media, titleKey: "gestalt.preset.videoOverCapture.title", detailKey: "gestalt.preset.videoOverCapture.detail", keys: [MGCacheDataLayout.spatialOverCaptureKey, MGCacheDataLayout.stereoAudioRecKey, MGCacheDataLayout.p3VideoRecKey], riskLevel: .medium),
        .init(id: "cameraControlPanel", category: .media, titleKey: "gestalt.preset.cameraControlPanel.title", detailKey: "gestalt.preset.cameraControlPanel.detail", keys: [MGCacheDataLayout.touchSensitiveCamControlKey, MGCacheDataLayout.hardwareDetentsKey, MGCacheDataLayout.cameraHapticsKey], riskLevel: .medium),
        .init(id: "legacyBattery", category: .media, titleKey: "gestalt.preset.legacyBattery.title", detailKey: "gestalt.preset.legacyBattery.detail", keys: [MGCacheDataLayout.legacyBatteryInfoKey, MGCacheDataLayout.legacyDynamicEndOfChargeKey], riskLevel: .low),

        // iPad
        .init(id: "pencil", category: .ipad, titleKey: "gestalt.preset.pencil.title", detailKey: "gestalt.preset.pencil.detail", keys: ["yhHcB0iH0d1XzPO/CFd3ow"], riskLevel: .low),
        .init(id: "stageManager", category: .ipad, titleKey: "gestalt.preset.stageManager.title", detailKey: "gestalt.preset.stageManager.detail", keys: ["qeaj75wk3HF4DwQ8qbIi7g"], riskLevel: .medium),
        .init(id: "ipadApps", category: .ipad, titleKey: "gestalt.preset.ipadApps.title", detailKey: "gestalt.preset.ipadApps.detail", keys: ["9MZ5AdH43csAUajl/dU+IQ"], riskLevel: .medium),

        // Intelligence
        .init(id: "ai", category: .intelligence, titleKey: "gestalt.preset.ai.title", detailKey: "gestalt.preset.ai.detail", keys: ["A62OafQ85EJAiiqKn4agtg"], riskLevel: .medium),
        .init(id: "siriOnDevice", category: .intelligence, titleKey: "gestalt.preset.siriOnDevice.title", detailKey: "gestalt.preset.siriOnDevice.detail", keys: ["K/R1GfGfCkXvEhaPS2Vrng"], riskLevel: .medium, preserveOnly: true),
        // Erosion-CN v0.8.5 finding (iPhone 18 Pro Max verified): Audio
        // Intelligence ships FALSE on every iPhone/iPad; enabling this slot
        // breaks the generative-model pipeline check and photos' high-quality
        // Clean Up errors out. Default-off with a factory-baseline guard.
        .init(id: "audioIntelligence", category: .intelligence, titleKey: "gestalt.preset.audioIntelligence.title", detailKey: "gestalt.preset.audioIntelligence.detail", keys: ["rb2tKZxlj0Gm2tBmUQSLqQ"], riskLevel: .high, requiresRiskConfirmation: true, factoryBaselineProtected: true),
        .init(id: "personalTranslator", category: .intelligence, titleKey: "gestalt.preset.personalTranslator.title", detailKey: "gestalt.preset.personalTranslator.detail", keys: ["M1n2sAqf33NAOgZRGxQYBA"], riskLevel: .medium),
        .init(id: "photosCleanUp", category: .intelligence, titleKey: "gestalt.preset.photosCleanUp.title", detailKey: "gestalt.preset.photosCleanUp.detail", keys: ["XNCjqOupLM/S8fNyxRNQTA"], riskLevel: .medium),
        .init(id: "handwritingSynthesis", category: .intelligence, titleKey: "gestalt.preset.handwritingSynthesis.title", detailKey: "gestalt.preset.handwritingSynthesis.detail", keys: ["YgYIIViDt1kgzyIsIV61vA"], riskLevel: .medium),
        .init(id: "alwaysListeningSiri", category: .intelligence, titleKey: "gestalt.preset.alwaysListeningSiri.title", detailKey: "gestalt.preset.alwaysListeningSiri.detail", keys: ["TusANsf9Lfe3P/9fIXXSrQ"], riskLevel: .medium),

        // Advanced
        .init(id: "internal", category: .advanced, titleKey: "gestalt.preset.internal.title", detailKey: "gestalt.preset.internal.detail", keys: ["EqrsVvjcYDdxHBiQmGhAWw"], riskLevel: .high, requiresRiskConfirmation: true),
        .init(id: "internalBuild", category: .advanced, titleKey: "gestalt.preset.internalBuild.title", detailKey: "gestalt.preset.internalBuild.detail", keys: ["LBJfwOEzExRxzlAnSuI7eg"], riskLevel: .high, requiresRiskConfirmation: true),
        .init(id: "internalSettings", category: .advanced, titleKey: "gestalt.preset.internalSettings.title", detailKey: "gestalt.preset.internalSettings.detail", keys: ["Oji6HRoPi7rH7HPdWVakuw"], riskLevel: .high, requiresRiskConfirmation: true),
        .init(id: "srd", category: .advanced, titleKey: "gestalt.preset.srd.title", detailKey: "gestalt.preset.srd.detail", keys: ["XYlJKKkj2hztRP1NWWnhlw"], riskLevel: .high, requiresRiskConfirmation: true),
        .init(id: "carPlayUltra", category: .advanced, titleKey: "gestalt.preset.carPlayUltra.title", detailKey: "gestalt.preset.carPlayUltra.detail", keys: [MGCacheDataLayout.carPlay2Key], riskLevel: .medium),
        .init(id: "touch120", category: .advanced, titleKey: "gestalt.preset.touch120.title", detailKey: "gestalt.preset.touch120.detail", keys: [MGCacheDataLayout.touchDelivery120HzKey], riskLevel: .medium),
        .init(id: "hearingAid", category: .advanced, titleKey: "gestalt.preset.hearingAid.title", detailKey: "gestalt.preset.hearingAid.detail", keys: [MGCacheDataLayout.hearingAidEQKey, MGCacheDataLayout.hearingAidLEKey, MGCacheDataLayout.hearingAidPowerRedKey], riskLevel: .medium),
        .init(id: "breathingApnea", category: .advanced, titleKey: "gestalt.preset.breathingApnea.title", detailKey: "gestalt.preset.breathingApnea.detail", keys: [MGCacheDataLayout.breathingDisturbancesKey], riskLevel: .medium),
        .init(id: "usBloodOxygen", category: .advanced, titleKey: "gestalt.preset.usBloodOxygen.title", detailKey: "gestalt.preset.usBloodOxygen.detail", keys: [MGCacheDataLayout.usBloodOxygenKey], riskLevel: .medium),
        .init(id: "workoutUltra", category: .advanced, titleKey: "gestalt.preset.workoutUltra.title", detailKey: "gestalt.preset.workoutUltra.detail", keys: [MGCacheDataLayout.workoutUltraKey, MGCacheDataLayout.timeInDaylightKey], riskLevel: .medium),
    ]

    static func presets(in category: GestaltPresetCategory) -> [GestaltPreset] {
        all.filter { $0.category == category }
    }

    static func preset(id: String) -> GestaltPreset? {
        all.first { $0.id == id }
    }

    /// Region-gate bits from CacheData (`green-tea` / `not-green-tea` /
    /// `wapi`). These have no CacheExtra entry, so the old checkup card could
    /// only show a hardcoded "ok" line. nil = CacheData unavailable.
    static func gateSnapshot() -> (
        greenTea: Bool?, notGreenTea: Bool?, wapi: Bool?
    ) {
        guard let root = try? GestaltPlistIO.readRoot(),
              let context = GestaltCacheDataBridge.context(root: root)
        else { return (nil, nil, nil) }
        return (
            GestaltCacheDataBridge.value(MGCacheDataLayout.greenTeaKey, in: context),
            GestaltCacheDataBridge.value(MGCacheDataLayout.notGreenTeaKey, in: context),
            GestaltCacheDataBridge.value(MGCacheDataLayout.wapiKey, in: context)
        )
    }
}

// MARK: - Apply / revert engine

enum GestaltPresetError: Error, Equatable {
    case unavailable
    case unreadable
    case invalidPlist
    case missingCacheExtra
    case keyNotInOriginalCache(key: String)
    case unsupportedValueType(key: String)
    case factoryBaselineProtected(key: String)
    case preserveOnly(key: String)
}

extension GestaltPresetError: LocalizedError {
    var errorDescription: String? {
        switch self {
        case .unavailable: return "gestalt.error.unavailable"
        case .unreadable: return "gestalt.error.unreadable"
        case .invalidPlist: return "gestalt.error.invalid"
        case .missingCacheExtra: return "gestalt.error.cache_extra"
        case .keyNotInOriginalCache: return "gestalt.presets.not_applicable"
        case .factoryBaselineProtected: return "gestalt.presets.factory_protected"
        case .unsupportedValueType: return "gestalt.error.value"
        case .preserveOnly: return "gestalt.presets.preserve_only"
        }
    }
}

/// Apply/revert engine for presets. Hard rule: a preset may only toggle keys
/// that ALREADY exist in the device's CacheExtra (iOS 27 anti-bounce rule).
/// Turning a key "on" that the device never had is refused with
/// `keyNotInOriginalCache` — the UI surfaces this as "not applicable on this
/// device" instead of a blind write.
/// Bridge to the binary `CacheData` slots.
///
/// MobileGestalt keeps hardware capability bits outside `CacheExtra`: the
/// key has no dictionary entry, only a validated 8-byte slot in the root's
/// `CacheData` blob. Reading `CacheExtra` alone therefore reports every
/// hardware/AI toggle as "not present" — the exact reason those rows used to
/// show no state.
enum GestaltCacheDataBridge {
    struct Context {
        let layout: MGCacheDataLayout
        let data: Data
    }

    static func context(root: [String: Any]) -> Context? {
        guard case .success(let pair) =
            MGCacheDataCoordinator.shared.resolveValidated(for: root as NSDictionary)
        else { return nil }
        return Context(layout: pair.0, data: pair.1)
    }

    static func hasSlot(_ key: String, in context: Context?) -> Bool {
        guard let context else { return false }
        return context.layout.slotIndex(forKey: key) != nil
    }

    static func value(_ key: String, in context: Context?) -> Bool? {
        guard let context,
              let index = context.layout.slotIndex(forKey: key),
              index >= 0,
              context.layout.validateSingleBooleanSlot(index, in: context.data)
        else { return nil }
        return context.data[index * 8] == 1
    }

    @discardableResult
    static func setValue(
        _ value: Bool, for key: String, in context: Context, data: inout Data
    ) -> Bool {
        guard let index = context.layout.slotIndex(forKey: key),
              index >= 0,
              index * 8 < data.count else { return false }
        data[index * 8] = value ? 1 : 0
        return true
    }
}

enum GestaltPresetEngine {

    /// Single-read batch evaluation (one plist read for ALL presets instead
    /// of 2N full 18MB parses per refresh).
    static func evaluateAll(
        _ presets: [GestaltPreset]
    ) -> (states: [String: Bool], applicability: [String: Bool]) {
        let root = (try? GestaltPlistIO.readRoot()) ?? [:]
        let cacheExtra = root["CacheExtra"] as? [String: Any] ?? [:]
        let cacheData = GestaltCacheDataBridge.context(root: root)
        var states: [String: Bool] = [:]
        var applicability: [String: Bool] = [:]
        for preset in presets {
            applicability[preset.id] = preset.keys.allSatisfy {
                cacheExtra[$0] != nil || GestaltCacheDataBridge.hasSlot($0, in: cacheData)
            }
            states[preset.id] = currentState(
                preset, cacheExtra: cacheExtra, cacheData: cacheData
            )
        }
        return (states, applicability)
    }

    static func currentState(for preset: GestaltPreset) throws -> Bool {
        let root = try GestaltPlistIO.readRoot()
        let cacheExtra = root["CacheExtra"] as? [String: Any] ?? [:]
        return currentState(
            preset,
            cacheExtra: cacheExtra,
            cacheData: GestaltCacheDataBridge.context(root: root)
        )
    }

    private static func currentState(
        _ preset: GestaltPreset,
        cacheExtra: [String: Any],
        cacheData: GestaltCacheDataBridge.Context?
    ) -> Bool {
        guard let firstKey = preset.keys.first else { return false }
        if let current = cacheExtra[firstKey] {
            if let custom = preset.values, let desired = custom[firstKey] {
                return isEqual(current, desired)
            }
            return (current as? NSNumber)?.boolValue == true
        }
        // Hardware capability slots: the key is absent from CacheExtra and
        // lives only in CacheData.
        return GestaltCacheDataBridge.value(firstKey, in: cacheData) ?? false
    }

    /// True when every key of the preset is readable on this device — either
    /// as a CacheExtra entry or as a validated CacheData slot.
    static func isApplicable(_ preset: GestaltPreset) -> Bool {
        guard let root = try? GestaltPlistIO.readRoot() else { return false }
        let cacheExtra = root["CacheExtra"] as? [String: Any] ?? [:]
        let cacheData = GestaltCacheDataBridge.context(root: root)
        return preset.keys.allSatisfy {
            cacheExtra[$0] != nil || GestaltCacheDataBridge.hasSlot($0, in: cacheData)
        }
    }

    /// Apply and report the resulting on/off state computed from the same
    /// in-memory root (a follow-up currentState(for:) used to cost a second
    /// full 18MB read+parse per toggle).
    static func applyReportingState(
        _ preset: GestaltPreset, enabled: Bool
    ) throws -> Bool {
        try apply(preset, enabled: enabled)
        return enabled ? desiredStateAfterEnable(preset) : false
    }

    private static func desiredStateAfterEnable(_ preset: GestaltPreset) -> Bool {
        guard let firstKey = preset.keys.first else { return false }
        if let custom = preset.values, let desired = custom[firstKey] {
            if let number = desired as? NSNumber {
                return number.boolValue != false && number.intValue != 0
            }
            return true
        }
        return true
    }

    static func apply(_ preset: GestaltPreset, enabled: Bool) throws {
        let path = GestaltKeys.gestaltPath
        let directory = (path as NSString).deletingLastPathComponent
        let grant = ContainerStore.grantContainerAccess(directory)
        defer {
            if grant >= 0 { SandboxAccess.release(grant) }
        }
        guard FileManager.default.fileExists(atPath: path) else {
            throw GestaltPresetError.unavailable
        }
        // Preserve-only presets never take generic writes from EITHER toggle
        // direction — their factory value is device-specific, and any
        // normalized write can revert the AI Siri interface. Restoration
        // goes through the baseline store via restorePreset() instead.
        if preset.preserveOnly {
            throw GestaltPresetError.preserveOnly(key: preset.id)
        }

        // Exclusive across read→mutate→write: two interleaved RMW sequences
        // from different editors would silently drop the first writer's keys.
        try GestaltPlistIO.withExclusiveAccess {
            var root = try GestaltPlistIO.readRoot()
            guard var cacheExtra = root["CacheExtra"] as? [String: Any] else {
                throw GestaltPresetError.missingCacheExtra
            }

            let cacheDataContext = GestaltCacheDataBridge.context(root: root)
            var cacheData = cacheDataContext?.data
            var cacheDataChanged = false

            let keys = GestaltEditPolicy.keysToApply(
                presetKeys: preset.keys,
                explicitEdits: GestaltExplicitEdits.keys()
            )
            for key in keys {
                // Anti-bounce guard: the key must already exist on this
                // device — as a CacheExtra entry OR a validated CacheData
                // slot. Hardware/AI bits live only in the latter.
                let inCacheExtra = cacheExtra[key] != nil
                let hasSlot = GestaltCacheDataBridge.hasSlot(key, in: cacheDataContext)
                guard inCacheExtra || hasSlot else {
                    throw GestaltPresetError.keyNotInOriginalCache(key: key)
                }
                if hasSlot && !inCacheExtra {
                    guard let context = cacheDataContext, var data = cacheData else {
                        throw GestaltPresetError.keyNotInOriginalCache(key: key)
                    }
                    // Same factory-baseline rule as CacheExtra: a slot that
                    // ships false must not be force-enabled.
                    if enabled, preset.factoryBaselineProtected,
                       GestaltCacheDataBridge.value(key, in: context) == false {
                        throw GestaltPresetError.factoryBaselineProtected(key: key)
                    }
                    guard GestaltCacheDataBridge.setValue(
                        enabled, for: key, in: context, data: &data
                    ) else {
                        throw GestaltPresetError.keyNotInOriginalCache(key: key)
                    }
                    cacheData = data
                    cacheDataChanged = true
                    continue
                }
                if enabled {
                    // Erosion-CN v0.8.5: slots that ship FALSE at the factory
                    // must not be force-enabled — the generative-model
                    // pipeline validation treats them as non-native and
                    // breaks sibling features (photos Clean Up).
                    if preset.factoryBaselineProtected,
                       let original = cacheExtra[key] as? NSNumber,
                       original.boolValue == false {
                        throw GestaltPresetError.factoryBaselineProtected(key: key)
                    }
                    if let custom = preset.values, let desired = custom[key] {
                        cacheExtra[key] = desired
                    } else {
                        // Type-preserving enable: keep the ORIGINAL value's
                        // CF type. A CFNumber→CFBoolean mutation (Integer 1 →
                        // true, Real 1.0 → true without keeping <real>) is a
                        // CacheExtra shape change MobileGestalt may reject.
                        if let original = cacheExtra[key] as? NSNumber {
                            switch GestaltValueKind.detect(original) {
                            case .real:
                                cacheExtra[key] = NSNumber(value: 1.0)
                            case .integer:
                                cacheExtra[key] = NSNumber(value: 1)
                            default:
                                cacheExtra[key] = NSNumber(value: true)
                            }
                        } else {
                            cacheExtra[key] = NSNumber(value: true)
                        }
                    }
                } else {
                    // Type-preserving disable: mirror the enable shape. The
                    // pre-enable original lives in the automatic BackupCenter
                    // snapshot (one tap restores it exactly); the direct off
                    // write only picks a same-typed falsy value so the cache
                    // shape never changes underneath MobileGestalt.
                    if let original = cacheExtra[key] as? NSNumber {
                        switch GestaltValueKind.detect(original) {
                        case .real:
                            cacheExtra[key] = NSNumber(value: 0.0)
                        case .integer:
                            cacheExtra[key] = NSNumber(value: 0)
                        default:
                            cacheExtra[key] = NSNumber(value: false)
                        }
                    } else {
                        cacheExtra[key] = NSNumber(value: false)
                    }
                }
            }

            guard !keys.isEmpty else {
                log("gestalt: preset \(preset.id) skipped — all keys explicitly edited")
                return
            }
            root["CacheExtra"] = cacheExtra
            if cacheDataChanged {
                guard let context = cacheDataContext, let data = cacheData else {
                    throw GestaltPresetError.unsupportedValueType(key: "CacheData")
                }
                root["CacheData"] = data
                // Re-validate the whole blob against the running library
                // before writing: a bad slot byte must never reach disk.
                if case .failure = context.layout.validatePlist(root as NSDictionary) {
                    throw GestaltPresetError.unsupportedValueType(key: "CacheData")
                }
            }
            try GestaltPlistIO.writeRoot(root, reason: "preset:\(preset.id)")
        }
        ActivityHistory.log(
            enabled ? .write : .restore,
            feature: "gestalt",
            "preset:\(preset.id)"
        )
        SoundEffects.play(.confirm)
    }

    // MARK: - Preserve-only presets (GestaltX #102/#98 semantics)

    /// Restore-Original for a preserve-only preset: writes back the FIRST
    /// observed value from the baseline store. Absence semantics apply —
    /// when the baseline recorded that the key did not exist, restore
    /// deletes it. Returns false when no baseline exists yet (nothing to
    /// restore; the UI then offers only "remove added key").
    @discardableResult
    static func restorePreset(_ preset: GestaltPreset) throws -> Bool {
        try GestaltPlistIO.withExclusiveAccess {
            var root = try GestaltPlistIO.readRoot()
            guard var cacheExtra = root["CacheExtra"] as? [String: Any] else {
                throw GestaltPresetError.missingCacheExtra
            }
            var restoredAny = false
            for key in preset.keys {
                let baselineKey = "CacheExtra.\(key)"
                guard let baseline = GestaltBaselineStore.shared.baseline(for: baselineKey) else {
                    continue
                }
                if let original = baseline.value {
                    cacheExtra[key] = original.anyValue
                } else {
                    cacheExtra.removeValue(forKey: key)
                }
                GestaltBaselineStore.shared.clearBaseline(fullKey: baselineKey)
                restoredAny = true
            }
            root["CacheExtra"] = cacheExtra
            try GestaltPlistIO.writeRoot(root, reason: "preset:\(preset.id)-restore")
            return restoredAny
        }
    }

    /// Remove-Key for preserve-only presets: deletes the CacheExtra entry
    /// entirely. NOT bound by the "only touch existing keys" anti-bounce
    /// rule — that rule guards ADDING keys, removal of an added one is the
    /// recovery path.
    static func removePresetKey(_ preset: GestaltPreset) throws {
        try GestaltPlistIO.withExclusiveAccess {
            var root = try GestaltPlistIO.readRoot()
            guard var cacheExtra = root["CacheExtra"] as? [String: Any] else {
                throw GestaltPresetError.missingCacheExtra
            }
            for key in preset.keys {
                cacheExtra.removeValue(forKey: key)
                GestaltBaselineStore.shared.clearBaseline(fullKey: "CacheExtra.\(key)")
            }
            root["CacheExtra"] = cacheExtra
            try GestaltPlistIO.writeRoot(root, reason: "preset:\(preset.id)-remove")
        }
        ActivityHistory.log(.restore, feature: "gestalt",
                            "preset:\(preset.id) key removed")
        SoundEffects.play(.confirm)
    }

    /// Records baselines for a preserve-only preset's keys on first sight
    /// (the UI calls this when rendering the row) so restore has an anchor
    /// even before the user touches anything.
    static func observePreserveOnly(_ preset: GestaltPreset) {
        let cacheExtra = (try? readCacheExtra()) ?? [:]
        for key in preset.keys {
            GestaltBaselineStore.shared.recordBaselineIfNeeded(
                fullKey: "CacheExtra.\(key)",
                currentValue: cacheExtra[key]
            )
        }
    }

    private static func isEqual(_ lhs: Any, _ rhs: Any) -> Bool {
        if let ln = lhs as? NSNumber, let rn = rhs as? NSNumber {
            return ln == rn
        }
        return "\(lhs)" == "\(rhs)"
    }

    private static func readCacheExtra() throws -> [String: Any] {
        let root = try GestaltPlistIO.readRoot()
        guard let cacheExtra = root["CacheExtra"] as? [String: Any] else {
            throw GestaltPresetError.missingCacheExtra
        }
        return cacheExtra
    }
}

/// Shared plist IO for the Gestalt editors: read with a sandbox grant,
/// write through the verified pipeline (serialize in the original format,
/// read the bytes back, then hand to VerifiedFileWriter for the automatic
/// pre-write backup and in-place inode-preserving replacement).
///
/// All read-modify-write sequences against the single MobileGestalt cache
/// MUST run inside `withExclusiveAccess`: preset engine, field editor and
/// region service each RMW this file from independent userInitiated queues,
/// and two interleaved sequences lose the first writer's keys silently.
/// MobileGestaltService (the safe-subset editor) takes the same lock so all
/// four pipelines serialize against each other.
enum GestaltPlistIO {
    private static let exclusiveLock = NSLock()

    static func withExclusiveAccess<T>(_ body: () throws -> T) rethrows -> T {
        exclusiveLock.lock()
        defer { exclusiveLock.unlock() }
        return try body()
    }

    static func readRoot() throws -> [String: Any] {
        try readRootWithFormat().root
    }

    /// Read the root AND its on-disk format in one pass, so the write path
    /// does not re-read the 18MB file just to detect binary vs XML.
    static func readRootWithFormat() throws -> (root: [String: Any], format: PropertyListSerialization.PropertyListFormat) {
        let path = GestaltKeys.gestaltPath
        let directory = (path as NSString).deletingLastPathComponent
        let grant = ContainerStore.grantContainerAccess(directory)
        defer {
            if grant >= 0 { SandboxAccess.release(grant) }
        }
        guard let data = FileManager.default.contents(atPath: path), !data.isEmpty else {
            throw GestaltPresetError.unreadable
        }
        var format = PropertyListSerialization.PropertyListFormat.binary
        guard let root = try? PropertyListSerialization.propertyList(
            from: data, options: [], format: &format
        ) as? [String: Any] else {
            throw GestaltPresetError.invalidPlist
        }
        return (root, format)
    }

    static func writeRoot(
        _ root: [String: Any],
        reason: String,
        format: PropertyListSerialization.PropertyListFormat? = nil
    ) throws {
        let path = GestaltKeys.gestaltPath
        let directory = (path as NSString).deletingLastPathComponent
        let grant = ContainerStore.grantContainerAccess(directory)
        defer {
            if grant >= 0 { SandboxAccess.release(grant) }
        }

        // Preserve the on-disk format (binary vs XML). Callers holding a
        // root from readRootWithFormat pass it in; otherwise probe once.
        let detectedFormat = format ?? {
            if let existing = FileManager.default.contents(atPath: path) {
                var probed = PropertyListSerialization.PropertyListFormat.binary
                _ = try? PropertyListSerialization.propertyList(
                    from: existing, options: [], format: &probed
                )
                return probed
            }
            return PropertyListSerialization.PropertyListFormat.binary
        }()
        let data: Data
        do {
            data = try PropertyListSerialization.data(
                fromPropertyList: root, format: detectedFormat, options: 0
            )
        } catch {
            throw GestaltPresetError.invalidPlist
        }
        guard !data.isEmpty else { throw GestaltPresetError.invalidPlist }
        // Read-back before writing: a malformed plist never reaches disk.
        guard (try? PropertyListSerialization.propertyList(from: data, options: [], format: nil)) != nil else {
            throw GestaltPresetError.invalidPlist
        }

        try VerifiedFileWriter.write(
            data,
            to: URL(fileURLWithPath: path),
            feature: .gestalt,
            reason: reason
        )
    }
}
