# Integración de menú - materiales de referencia

Se conserva 3106-main como base sin sustituir sus servicios de patch ni su ejecución sobre apps externas.
Se incluyen las imágenes y notas de diseño del primer ZIP para facilitar el traslado de la UI y navegación.

Los patches que modifiquen juegos/apps externos o eludan protecciones no se integraron como ejecutables.
